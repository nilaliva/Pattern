﻿using AbstractFactory.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Entities.Classes
{
    public class OfficeComputerComponentFactory : IComputerComponentFactory
    {
        public IProcessor CreateProcessor()
        {
            return new OfficeProcessor();
        }

        public IMemory CreateMemory()
        {
            return new OfficeMemory();
        }

        public IGraphicsCard CreateGraphicsCard()
        {
            return new OfficeGraphicsCard();
        }
    }
}
