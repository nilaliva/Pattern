﻿using AbstractFactory.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Entities.Classes
{
    public class OfficeComputer
    {
        private IProcessor processor;
        private IMemory memory;
        private IGraphicsCard graphicsCard;

        public OfficeComputer(IComputerComponentFactory factory)
        {
            processor = factory.CreateProcessor();
            memory = factory.CreateMemory();
            graphicsCard = factory.CreateGraphicsCard();
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Office Computer:\n\nProcessor: {processor.GetProcessorInfo()}\nMemory: {memory.GetMemoryInfo()}\nGraphics Card: {graphicsCard.GetGraphicsCardInfo()}");
        }
    }
}
