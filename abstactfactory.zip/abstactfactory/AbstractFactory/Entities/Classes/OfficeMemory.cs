﻿using AbstractFactory.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Entities.Classes
{
    public class OfficeMemory : IMemory
    {
        public string GetMemoryInfo()
        {
            return "8GB RAM";
        }
    }
}
