﻿using AbstractFactory.Entities.Classes;
using AbstractFactory.Entities.Interfaces;

class Program
{
    static void Main()
    {
        IComputerComponentFactory officeFactory = new OfficeComputerComponentFactory();
        OfficeComputer officeComputer = new OfficeComputer(officeFactory);
        officeComputer.DisplayInfo();
    }
}