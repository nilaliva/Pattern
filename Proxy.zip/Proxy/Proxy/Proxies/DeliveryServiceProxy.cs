﻿using Proxy.Entities.Classes;
using Proxy.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy.Proxies
{
    public class DeliveryServiceProxy : IDeliveryService
    {
        private RealDeliveryService realDeliveryService;
        private string product;
        private bool isDelivered;

        public DeliveryServiceProxy(string product)
        {
            this.product = product;
        }

        public void Deliver(string product)
        {
            if (realDeliveryService == null)
            {
                realDeliveryService = new RealDeliveryService();
            }

            realDeliveryService.Deliver(product);
            isDelivered = true;
            Console.WriteLine($"Status: Delivered {product}");
        }
    }
}
