﻿using Proxy.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy.Entities.Classes
{
    public class RealDeliveryService : IDeliveryService
    {
        public void Deliver(string product)
        {
            Console.WriteLine($"Delivering {product} to the customer");
        }
    }
}
