﻿using Proxy.Entities.Interfaces;
using Proxy.Proxies;

class Program
{
    static void Main()
    {
        IDeliveryService deliveryService = new DeliveryServiceProxy("Electronics");
        deliveryService.Deliver("Electronics");
        deliveryService.Deliver("Electronics");
    }
}