﻿using State.Classes;

class Program
{
    static void Main()
    {
        Computer computer = new Computer();
        computer.PowerOn();
        computer.Sleep();
        computer.PowerOff();

        computer.SetState(new PowerOnState());
        computer.Sleep();
        computer.PowerOff();
    }
}