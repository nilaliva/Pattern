﻿using State.Classes;
using State.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Computer
{
    private IComputerState currentState;

    public Computer()
    {
        currentState = new PowerOffState();
    }

    public void SetState(IComputerState state)
    {
        currentState = state;
    }

    public void PowerOn()
    {
        currentState.PowerOn();
    }

    public void PowerOff()
    {
        currentState.PowerOff();
    }

    public void Sleep()
    {
        currentState.Sleep();
    }
}