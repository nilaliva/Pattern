﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using State.Entities.Interfaces;
using System;


namespace State.Classes
{
    public class PowerOffState : IComputerState
    {
        public void PowerOn()
        {
            Console.WriteLine("Downloading up the computer");
        }

        public void PowerOff()
        {
            Console.WriteLine("Computer is powered off");
        }

        public void Sleep()
        {
            Console.WriteLine("Cannot sleep when the computer is powered off");
        }
    }
}
