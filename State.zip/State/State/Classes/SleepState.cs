﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using State.Entities.Interfaces;
using System;


namespace State.Classes
{
    public class SleepState : IComputerState
    {
        public void PowerOn()
        {
            Console.WriteLine("Opening computer from sleep mood");
        }

        public void PowerOff()
        {
            Console.WriteLine("Shutting down the computer from sleep mode");
        }

        public void Sleep()
        {
            Console.WriteLine("Computer is on sleep mode");
        }
    }
}
