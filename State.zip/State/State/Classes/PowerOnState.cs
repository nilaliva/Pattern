﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using State.Entities.Interfaces;
using System;


namespace State.Classes
{
    public class PowerOnState : IComputerState
    {
        public void PowerOn()
        {
            Console.WriteLine("Computer is powered on");
        }

        public void PowerOff()
        {
            Console.WriteLine("Shutting down the computer");
        }

        public void Sleep()
        {
            Console.WriteLine("Getting computer to sleep.");
        }
    }
}
