﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State.Entities.Interfaces
{
    public interface IComputerState
    {
        void PowerOn();
        void PowerOff();
        void Sleep();
    }
}
