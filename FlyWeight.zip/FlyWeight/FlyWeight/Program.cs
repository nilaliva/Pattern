﻿using FlyWeight.Entities.Classes;
using FlyWeight.Subjects.Classes;

class Program
{
    static void Main()
    {
        WeatherStation weatherStation = new WeatherStation();
        WeatherObserver observer1 = new WeatherObserver("Observer 1");
        WeatherObserver observer2 = new WeatherObserver("Observer 2");
        weatherStation.AddObserver(observer1);
        weatherStation.AddObserver(observer2);
        weatherStation.SetWeather("Cloudy");
        weatherStation.RemoveObserver(observer1); 
        weatherStation.SetWeather("Rainy");
    }
}