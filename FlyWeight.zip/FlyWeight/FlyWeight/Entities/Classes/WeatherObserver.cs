﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlyWeight.Entities.Interfaces;
using System; 

namespace FlyWeight.Entities.Classes
{

    public class WeatherObserver : IObserver
    {
        private string observerName;

        public WeatherObserver(string name)
        {
            observerName = name;
        }

        public void Update(string weather)
        {
            Console.WriteLine($"{observerName} weather update: {weather}");
        }
    }
}
