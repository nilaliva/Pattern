﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlyWeight.Entities.Interfaces;
using FlyWeight.Subjects.Interfaces;
using System;
using System.Collections.Generic;

namespace FlyWeight.Subjects.Classes
{

    public class WeatherStation : ISubject
    {
        private List<IObserver> observers = new List<IObserver>();
        private string currentWeather;

        public void AddObserver(IObserver observer)
        {
            observers.Add(observer);
        }

        public void RemoveObserver(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void NotifyObservers()
        {
            foreach (var observer in observers)
            {
                observer.Update(currentWeather);
            }
        }

        public void SetWeather(string weather)
        {
            currentWeather = weather;
            Console.WriteLine($"Weather updated: {currentWeather}");
            NotifyObservers();
        }
    }
}
