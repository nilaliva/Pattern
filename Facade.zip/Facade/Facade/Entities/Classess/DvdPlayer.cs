﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Entities.Classess
{
    public class DvdPlayer
    {
        public void InsertDisc(string movieTitle)
        {
            Console.WriteLine($"Inserting Dvd: {movieTitle}");
        }

        public void EjectDisc()
        {
            Console.WriteLine("Ejecting Dvd");
        }
    }
}
