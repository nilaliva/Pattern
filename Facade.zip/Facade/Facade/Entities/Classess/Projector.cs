﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Entities.Classess
{
    public class Projector
    {
        public void TurnOn()
        {
            Console.WriteLine("Projector on");
        }

        public void TurnOff()
        {
            Console.WriteLine("Projector off");
        }
    }
}
