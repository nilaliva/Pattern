﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Entities.Classess
{
    public class Sound
    {
        public void TurnOn()
        {
            Console.WriteLine("Sound on");
        }

        public void TurnOff()
        {
            Console.WriteLine("Sound off");
        }
    }
}
