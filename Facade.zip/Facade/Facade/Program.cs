﻿using Facade.Entities.Interfaces;
using Facade.Facades;

class Program
{
    static void Main()
    {
        IMoviePlayer moviePlayer = new MoviePlayerFacade();
        moviePlayer.PlayMovie("Avengers-Endgame");
        moviePlayer.StopMovie();
    }
}