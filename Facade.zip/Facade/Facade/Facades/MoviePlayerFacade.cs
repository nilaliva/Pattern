﻿using Facade.Entities.Classess;
using Facade.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade.Facades
{
    public class MoviePlayerFacade : IMoviePlayer
    {
        private DvdPlayer dvdPlayer;
        private Projector projector;
        private Sound soundSystem;

        public MoviePlayerFacade()
        {
            dvdPlayer = new DvdPlayer();
            projector = new Projector();
            soundSystem = new Sound();
        }

        public void PlayMovie(string movieTitle)
        {
            Console.WriteLine($"Playing movie: {movieTitle}");
            dvdPlayer.InsertDisc(movieTitle);
            projector.TurnOn();
            soundSystem.TurnOn();
        }

        public void StopMovie()
        {
            Console.WriteLine("Stopping movie...");
            dvdPlayer.EjectDisc();
            projector.TurnOff();
            soundSystem.TurnOff();
        }
    }

}
