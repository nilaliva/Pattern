﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class ComputerDirector
{
    public void ConstructComputer(IComputerBuilder builder)
    {
        builder.BuildProcessor();
        builder.BuildMemory();
        builder.BuildMotherBoard();
        builder.BuildStorage();
        builder.BuildOperatingSystem();
    }
}