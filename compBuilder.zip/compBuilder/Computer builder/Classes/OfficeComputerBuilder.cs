﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class OfficeComputerBuilder : IComputerBuilder
{
    private Computer computer = new Computer();

    public void BuildProcessor()
    {
        computer.Processor = "Intel Core i5";
    }

    public void BuildMemory()
    {
        computer.Memory = 16;
    }
    public void BuildMotherBoard()
    {
        computer.MotherBoard = "CPU";
    }

    public void BuildStorage()
    {
        computer.Storage = 256;
    }

    public void BuildOperatingSystem()
    {
        computer.OperatingSystem = "Windows 10";
    }

    public Computer GetComputer()
    {
        return computer;
    }
}