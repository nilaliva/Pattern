﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Computer
{
    public string Processor { get; set; }
    public int Memory { get; set; }
    public string MotherBoard { get; set; }
    public int Storage { get; set; }
    public string OperatingSystem { get; set; }

    public override string ToString()
    {
        return $"Computer: {Processor}, {Memory}GB, {Storage}GB storage, {MotherBoard}-MotherBoard, {OperatingSystem}";
    }
}