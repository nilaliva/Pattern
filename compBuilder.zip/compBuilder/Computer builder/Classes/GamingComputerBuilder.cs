﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class GamingComputerBuilder : IComputerBuilder
{
    private Computer computer = new Computer();

    public void BuildProcessor()
    {
        computer.Processor = "AMD Ryzen 9";
    }

    public void BuildMemory()
    {
        computer.Memory = 32;
    }

    public void BuildMotherBoard()
    {
        computer.MotherBoard = "CPU";
    }

    public void BuildStorage()
    {
        computer.Storage = 512;
    }

    public void BuildOperatingSystem()
    {
        computer.OperatingSystem = "Windows 10";
    }

    public Computer GetComputer()
    {
        return computer;
    }
}