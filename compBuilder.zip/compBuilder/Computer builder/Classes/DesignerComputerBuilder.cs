﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class DesignerComputerBuilder : IComputerBuilder
{
    private Computer computer = new Computer();

    public void BuildProcessor()
    {
        computer.Processor = "AMD Ryzen 7";
    }

    public void BuildMemory()
    {
        computer.Memory = 64;
    }
    public void BuildMotherBoard()
    {
        computer.MotherBoard = "CPU";
    }
    public void BuildStorage()
    {
        computer.Storage = 1000;
    }

    public void BuildOperatingSystem()
    {
        computer.OperatingSystem = "macOS";
    }

    public Computer GetComputer()
    {
        return computer;
    }
}