﻿using System;

class Program
{
    static void Main()
    {
        IComputerBuilder officeBuilder = new OfficeComputerBuilder();
        IComputerBuilder gamingBuilder = new GamingComputerBuilder();
        IComputerBuilder designerBuilder = new DesignerComputerBuilder();

        ComputerDirector director = new ComputerDirector();

        director.ConstructComputer(officeBuilder);
        Computer officeComputer = officeBuilder.GetComputer();
        Console.WriteLine("Office Computer: " + officeComputer);

        director.ConstructComputer(gamingBuilder);
        Computer gamingComputer = gamingBuilder.GetComputer();
        Console.WriteLine("Gaming Computer: " + gamingComputer);

        director.ConstructComputer(designerBuilder);
        Computer designerComputer = designerBuilder.GetComputer();
        Console.WriteLine("Designer Computer: " + designerComputer);
    }
}