﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public interface IComputerBuilder
{
    void BuildProcessor();
    void BuildMemory();
    void BuildMotherBoard();
    void BuildStorage();
    void BuildOperatingSystem();
    Computer GetComputer();
}